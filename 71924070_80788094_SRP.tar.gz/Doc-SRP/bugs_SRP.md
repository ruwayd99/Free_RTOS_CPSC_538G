# bugs_SRP.md 
Current list of known defects and soft spots in the SRP and
stack-sharing implementation.

---

## 1. Functional bugs

### 1.1 Admission `B_i` is over-approximate for multi-unit resources

`prvSRPComputeBlockingBoundForLevel` treats each resource as if the
entire critical section of the worst low-level user could block the
candidate. For a multi-unit resource where the user only needs
`units_needed < uxTotalUnits`, the real blocking bound can be smaller
(the candidate may run concurrently on the remaining units). The
admission test is therefore **safe but pessimistic** and we reject some
sets that are actually feasible.

**Impact.** None of the provided tests hit the pessimism boundary, but
on dense workloads this will produce false rejections.

### 1.2 `vSRPResourceRegisterUser` is not called for dynamically-created resources after admission

The API is "register before admit." If a test creates a new resource
at runtime and calls `vSRPResourceRegisterUser` for an already-admitted
task, that task's `xSRPBlockingBound` is **not** recomputed. The
admission snapshot is stale.

**Mitigation.** Test code always registers users before admission.
**Fix.** Implement an `xTaskRevalidateAdmission` hook that re-runs
`prvEDFAdmissionControl` over the current set plus new blocking
terms.

### 1.3 No tracking of which resources a task is "allowed" to take

Nothing prevents a task from calling `xSRPResourceTake` on a resource
for which it was not registered. The assertions inside
`xSRPResourceTake` will fail only if `uxUnits > uxAvailableUnits`. A
rogue caller that takes a resource without registering will bypass the
`B_i` accounting entirely.

**Fix.** Track per-task registrations and assert on take.

---

## 2. Stack-sharing bugs

### 2.1 Snapshot is allocated from the same heap that sharing is supposed to save

Every shared-stack task allocates a private snapshot
(`pxPrivateContextSnapshot`) from `pvPortMalloc`. For Cortex-M0+ the
initial frame is ~20 words = 80 bytes, so 100 tasks waste ~8 KB of
heap. The net savings vs. full per-task stacks are still large (~66%
in the 100-task demo), but we're paying a small "sharing tax" that a
smarter implementation would avoid.

**Fix options.**
* Put snapshots in a per-group `.bss` array the same way stack buffers
  are allocated.
* Reconstruct the initial frame from a tiny template + the task entry
  point + pvParameters at dispatch time instead of storing a full copy.

### 2.2 Snapshot size is computed from `pxTopOfStack - buffer_end` — port-dependent

`uxPrivateContextWords = buffer_top - pxTopOfStack` assumes the port's
initial frame is contiguous and sits at the top of the buffer. The
RP2040 Cortex-M0+ port is well-behaved, but if this code ever moves to
a port that initializes the frame differently the `memcpy` in the dispatch
hook will fail silently.

**Mitigation.** A `configASSERT` bounds-check is already in
`xTaskCreateEDFWithStack`, but it only catches out-of-buffer, not
wrong-shape. Needs a port-abstracted "initial frame size" API.

---

## 3. Trace / observability bugs

### 3.1 `[SRP][BLOCK]` can flood the UART under ceiling contention

When a task is ceiling-blocked, the selector runs every context
switch and emits a trace line. Under high tick rate with many
blocked tasks the UART backpressures everything. Observed in
Mode OFF of the 100-task test for ~200 ms while admission was still
running.

**Mitigation.** Raise `configTICK_RATE_HZ` only as needed.
**Fix.** Rate-limit the trace (emit once per `(task, ceiling)`
transition, not per-selection).

---

## 4. Build / configuration issues

### 4.1 `configMAX_SRP_RESOURCES = 8` and `configMAX_SRP_USERS_PER_RESOURCE = 16` are hard-coded in `FreeRTOSConfig.h`

Not a bug, but may be an issue on larger deployments. The
`xSRPResources` storage is sized at compile time; exceeding these
limits produces a `configASSERT` at runtime rather than a nicer
diagnostic.
